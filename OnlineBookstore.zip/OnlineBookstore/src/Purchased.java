public class Purchased {



    public Purchased()

    {


    }
}
