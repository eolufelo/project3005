public class User {

    String username, shipping_address, billing_address, name;

    public User (String u, String ship, String bill, String n)
    {
        username = u;
        shipping_address = ship;
        billing_address = bill;
        name = n;
    }

    public String getUsername() {return username;}

}
