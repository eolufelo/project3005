import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.awt.event.ActionEvent;
import java.util.ArrayList;



public class OnlineBookStoreApp extends Application {
        public void start(Stage primaryStage) {

            Integer  ISBN, pages, inventory, num_sales;
            Publisher publisher;
            double price;
            float publisher_percentage;


            String  name, author, genre;


            ArrayList<Book> books_in_cart = new ArrayList<>();

            OnlineBookstore obs = new OnlineBookstore("BookStore1");

            User u1 = new User("User1","123 careltonU road", "123 Carleton road", "Hassem Aouar" );
            User u2 = new User("User2","10 Kanata road", "10 Kanata road", "John Barnes" );
            User u3 = new User("User3","3 Colonel ByDrive road", "3 Colonel ByDrive road", "Emmanuel Petite" );
            User u4 = new User("User4","5 tottenham", "5 tottenham road", "Lucas Moura" );

            obs.newUser(u1);
            obs.newUser(u2);
            obs.newUser(u3);
            obs.newUser(u4);

            Publisher penguin = new Publisher("Penguin Random House", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,001);
            Publisher hachette = new Publisher("Hachette Livre", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,002);
            Publisher harper = new Publisher("HarperCollins", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,003);
            Publisher macmillan = new Publisher("Macmillan Publishers", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,004);
            Publisher simon = new Publisher("Simon & Schuster", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,005);
            Publisher mhe = new Publisher("McGraw-Hill Education", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,006);
            Publisher houghton = new Publisher("Houghton Mifflin Harcourt", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,007);

            Book b1 = new Book(978052552, "The Glass Hotel", "EMILY ST. JOHN MANDEL", "Literary Fiction", penguin, 320,26.95, 10, 5);
            Book b2 = new Book(888052552, "Stop At Nothing: The Explosive New Thriller James Patterson Calls 'flawless'", " Michael Ledwidge", "Mystery", hachette, 303,14.99, 10, 5);

            obs.addPublisher(penguin);
            obs.addPublisher(hachette);
            obs.addPublisher(harper);
            obs.addPublisher(macmillan);
            obs.addPublisher(simon);
            obs.addPublisher(mhe);
            obs.addPublisher(houghton);

            obs.addBook(b1);
            obs.addBook(b2);

            obs.printBooks();


            Label blabel = new Label("Books in the Library");

// ----------------------------------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------------------------------
// Main Pane

            GridPane mainPane = new GridPane();
            mainPane.setPadding(new Insets(10, 10, 10, 10));
            mainPane.setHgap(1);
            mainPane.setVgap(1);

            Button edit_book_store_button = new Button("Edit Catalogue");
            Button go_shopping_button = new Button("Shop For Books");
            Button new_publisher_button = new Button("New Publisher");
            Button create_user_button = new Button("New User");
            Button track_order_button = new Button("Track an Order");

            mainPane.add(edit_book_store_button,0,2);
            mainPane.add(go_shopping_button,0 ,3);
            mainPane.add(new_publisher_button,0,4);
            mainPane.add(create_user_button,0,5);
            mainPane.add(track_order_button,1, 2 );


            mainPane.setMargin(blabel, new Insets(0, 0, 10, 0));
            mainPane.add(blabel,0,0);

            ListView<Book> bookList_main = new ListView<Book>();
            bookList_main.getItems().addAll(obs.books.values());


            bookList_main.setPrefWidth(Integer.MAX_VALUE);
            bookList_main.setPrefHeight(Integer.MAX_VALUE);
            mainPane.add(bookList_main,0 ,1);

            edit_book_store_button.setMinHeight(30);
            edit_book_store_button.setMinWidth(130);
            go_shopping_button.setMinHeight(30);
            go_shopping_button.setMinWidth(130);
            new_publisher_button.setMinHeight(30);
            new_publisher_button.setMinWidth(130);
            create_user_button.setMinHeight(30);
            create_user_button.setMinWidth(130);
            track_order_button.setMinHeight(30);
            track_order_button.setMinWidth(130);


            Scene mp = new Scene(mainPane, 500,320);

            primaryStage.setTitle("Online BookStore");
            primaryStage.setScene(mp);
            primaryStage.show();




//------------------------------------------------------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------------------
// Edit Book Store Pane

            GridPane aPane = new GridPane();
            Scene ap =  new Scene(aPane, 420,320);
            aPane.setPadding(new Insets(10, 10, 10, 10));
            aPane.setHgap(1);
            aPane.setVgap(1);


            //TextField newItemField = new TextField();
            //aPane.add(newItemField,0,0);


            Label books_label = new Label("Books in the Library");
            aPane.setMargin(books_label, new Insets(0, 0, 10, 0));
            aPane.add(books_label,0,0);

            Button addButton = new Button("Add Book");
            aPane.add(addButton,1,0);

            ListView<Book> bookList = new ListView<Book>();
            bookList.getItems().addAll(obs.books.values());

            bookList.setPrefWidth(Integer.MAX_VALUE);
            bookList.setPrefHeight(Integer.MAX_VALUE);

            aPane.add(bookList,0,1);


            Button removeButton = new Button("Remove Book");
            aPane.add(removeButton,1,1);

            Button main_menu = new Button("Main Menu");
            aPane.add(main_menu,1,1);
            aPane.setValignment(removeButton, VPos.BOTTOM);

            addButton.setMinHeight(30);
            addButton.setMinWidth(100);
            removeButton.setMinHeight(30);
            removeButton.setMinWidth(100);


            aPane.setValignment(removeButton, VPos.TOP);
// ----------------------------------------------------------------------------------------------------------------------------------------
// -- shop pane
            GridPane shop_Pane = new GridPane();
            Scene sp =  new Scene(shop_Pane, 620,420);
            aPane.setPadding(new Insets(10, 10, 10, 10));
            aPane.setHgap(1);
            aPane.setVgap(1);

            Button add_to_cart_button = new Button("Add to Cart");
            Button view_cart_button = new Button("View Cart");
            Button mm_button = new Button ("Main Menu");
            Button search_for_book_button = new Button("Search for Book \nby ISBN only");
            Button search_everything_button = new Button("Search");


            add_to_cart_button.setMinHeight(30);
            add_to_cart_button.setMinWidth(100);
            view_cart_button.setMinHeight(30);
            view_cart_button.setMinWidth(100);
            mm_button.setMinHeight(30);
            mm_button.setMinWidth(100);
            search_for_book_button.setMinHeight(60);
            search_for_book_button.setMinWidth(100);
            search_everything_button.setMinHeight(30);
            search_everything_button.setMinWidth(100);


            ListView<Book> bookList_shopPane = new ListView<Book>();
            bookList_shopPane.getItems().addAll(obs.books.values());
            bookList_shopPane.setMaxWidth(Integer.MAX_VALUE);
            bookList_shopPane.setMaxHeight(Integer.MAX_VALUE);
            bookList_shopPane.setMinWidth(200);

            GridPane butPane = new GridPane();
            butPane.setMinWidth(100);

            GridPane search_field_Pane = new GridPane();
            search_field_Pane.setMinWidth(200);

            shop_Pane.add(bookList_shopPane,0,0);
            butPane.add(add_to_cart_button,0,0);
            butPane.add(view_cart_button,0,1);
            butPane.add(mm_button,0,2);
            butPane.add(search_for_book_button,0,3);
            butPane.add(search_everything_button,0,4);

            shop_Pane.add(butPane,1,0);
            shop_Pane.add(search_field_Pane,2,0);

            // -------- search field pane

            TextField ISBN_Field_shop = new TextField();
            Label ISBN_label_shop = new Label("ISBN");

            search_field_Pane.setMargin(ISBN_label_shop, new Insets(0, 0, 10, 0));
            search_field_Pane.add(ISBN_label_shop,0,0);

            TextField bookn_Field_shop = new TextField();
            Label b_label_shop = new Label("Book Name");
            search_field_Pane.setMargin(b_label_shop, new Insets(0, 0, 10, 0));
            search_field_Pane.add(b_label_shop,0,1);

            TextField author_Field_shop = new TextField();
            Label author_label_shop = new Label("Author");
            search_field_Pane.setMargin(author_label_shop, new Insets(0, 0, 10, 0));
            search_field_Pane.add(author_label_shop,0,2);

            TextField genre_Field_shop = new TextField();
            Label genre_label_shop = new Label("Genre");
            search_field_Pane.setMargin(genre_label_shop, new Insets(0, 0, 10, 0));
            search_field_Pane.add(genre_label_shop,0,3);

            TextField publisher_Field_shop = new TextField();
            Label pub_label_shop = new Label("Publisher");
            search_field_Pane.setMargin(pub_label_shop, new Insets(0, 0, 10, 0));
            search_field_Pane.add(pub_label_shop,0,4);

            TextField pages_Field_shop = new TextField();
            Label pages_label_shop = new Label("Pages");
            search_field_Pane.setMargin(pages_label_shop, new Insets(0, 0, 10, 0));
            search_field_Pane.add(pages_label_shop,0,5);

            TextField price_Field_shop = new TextField();
            Label price_label_shop = new Label("Price");
            search_field_Pane.setMargin(price_label_shop, new Insets(0, 0, 10, 0));
            search_field_Pane.add(price_label_shop,0,6);


            search_field_Pane.add(ISBN_Field_shop,1,0);
            search_field_Pane.add(bookn_Field_shop ,1,1);
            search_field_Pane.add(author_Field_shop,1,2);
            search_field_Pane.add(genre_Field_shop,1,3);
            search_field_Pane.add(publisher_Field_shop,1,4);

            search_field_Pane.add(pages_Field_shop,1,5);
            search_field_Pane.add(price_Field_shop,1,6);











// ----------------------------------------------------------------------------------------------------------------------
//-- new User Pane

            GridPane new_user_Pane = new GridPane();
            Scene nup =  new Scene(new_user_Pane, 420,320);
            new_user_Pane.setPadding(new Insets(10, 10, 10, 10));
            new_user_Pane.setHgap(1);
            new_user_Pane.setVgap(1);


            TextField username_Field = new TextField();
            Label username_label = new Label("Username");
            new_user_Pane.setMargin(username_label, new Insets(0, 0, 10, 0));
            new_user_Pane.add(username_label,0,0);

            TextField ship_Field = new TextField();
            Label ship_label = new Label("Shipping Address");
            new_user_Pane.setMargin(ship_label, new Insets(0, 0, 10, 0));
            new_user_Pane.add(ship_label,0,1);

            TextField bill_Field = new TextField();
            Label bill_label = new Label("Billing Address");
            new_user_Pane.setMargin(bill_label, new Insets(0, 0, 10, 0));
            new_user_Pane.add(bill_label,0,2);

            TextField name_Field = new TextField();
            Label name_label = new Label("Name");
            new_user_Pane.setMargin(name_label, new Insets(0, 0, 10, 0));
            new_user_Pane.add(name_label,0,3);




            new_user_Pane.add(username_Field,1,0);
            new_user_Pane.add(ship_Field ,1,1);
            new_user_Pane.add(bill_Field,1,2);
            new_user_Pane.add(name_Field,1,3);

            Button add_user_Button = new Button("Add User");
            new_user_Pane.add(add_user_Button,1,9);
            Button cancel_button_nu = new Button("Cancel");
            new_user_Pane.add(cancel_button_nu,2,9);



//----------------------------------------------------------------------------------------------------------------------
//-- new Publisher Pane






//------------------------------------------------------------------------------------------------------------------------------------
// add Book pane

            GridPane add_Pane = new GridPane();
            Scene addp =  new Scene(add_Pane, 420,320);
            add_Pane.setPadding(new Insets(10, 10, 10, 10));
            add_Pane.setHgap(1);
            add_Pane.setVgap(1);


            TextField ISBN_Field = new TextField();
            Label ISBN_label = new Label("ISBN");
            add_Pane.setMargin(ISBN_label, new Insets(0, 0, 10, 0));
            add_Pane.add(ISBN_label,0,0);

            TextField bookn_Field = new TextField();
            Label b_label = new Label("Book Name");
            add_Pane.setMargin(b_label, new Insets(0, 0, 10, 0));
            add_Pane.add(b_label,0,1);

            TextField author_Field = new TextField();
            Label author_label = new Label("Author");
            add_Pane.setMargin(author_label, new Insets(0, 0, 10, 0));
            add_Pane.add(author_label,0,2);

            TextField genre_Field = new TextField();
            Label genre_label = new Label("Genre");
            add_Pane.setMargin(genre_label, new Insets(0, 0, 10, 0));
            add_Pane.add(genre_label,0,3);

            TextField publisher_Field = new TextField();
            Label pub_label = new Label("Publisher");
            add_Pane.setMargin(pub_label, new Insets(0, 0, 10, 0));
            add_Pane.add(pub_label,0,4);

            TextField pages_Field = new TextField();
            Label pages_label = new Label("Pages");
            add_Pane.setMargin(pages_label, new Insets(0, 0, 10, 0));
            add_Pane.add(pages_label,0,5);

            TextField price_Field = new TextField();
            Label price_label = new Label("Price");
            add_Pane.setMargin(price_label, new Insets(0, 0, 10, 0));
            add_Pane.add(price_label,0,6);

            TextField inventory_Field = new TextField();
            Label inv_label = new Label("Inventory");
            add_Pane.setMargin(inv_label, new Insets(0, 0, 10, 0));
            add_Pane.add(inv_label,0,7);

            TextField pp_Field = new TextField();
            Label pp_label = new Label("Publisher Percentage");
            add_Pane.setMargin(pp_label, new Insets(0, 0, 10, 0));
            add_Pane.add(pp_label,0,8);


            add_Pane.add(ISBN_Field,1,0);
            add_Pane.add(bookn_Field ,1,1);
            add_Pane.add(author_Field,1,2);
            add_Pane.add(genre_Field,1,3);
            add_Pane.add(publisher_Field,1,4);

            add_Pane.add(pages_Field,1,5);
            add_Pane.add(price_Field,1,6);
            add_Pane.add(inventory_Field,1,7);
            add_Pane.add(pp_Field,1,8);

            Button add_book_Button = new Button("Add Book");
            add_Pane.add(add_book_Button,1,9);

            Button cancel_button = new Button("Cancel");
            add_Pane.add(cancel_button,2,9);


//------------------------------------------------------------------------------------------------------------------------------------
// Remove Book pane


            GridPane remove_Pane = new GridPane();
            Scene rmp =  new Scene(remove_Pane, 420,320);
            add_Pane.setPadding(new Insets(10, 10, 10, 10));
            add_Pane.setHgap(1);
            add_Pane.setVgap(1);

            TextField ISBN_Field_rm = new TextField();
            Label ISBN_label_rm = new Label("ISBN");
            remove_Pane.setMargin(ISBN_label_rm, new Insets(0, 0, 10, 0));
            remove_Pane.add(ISBN_label_rm,0,0);
            remove_Pane.add(ISBN_Field_rm,1,0);

            Button rm_book_Button = new Button("Remove Book");
            remove_Pane.add(rm_book_Button,1,9);

            Button cancel_button_rm = new Button("Cancel");
            remove_Pane.add(cancel_button_rm,2,9);



//------------------------------------------------------------------------------------------------------------------------------------


            //---------------- main pane

            create_user_button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    System.out.println("New User has been pressed");
                    primaryStage.setScene(nup);
                }
            });


            edit_book_store_button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    System.out.println("Edit Book Store has been pressed");
                    primaryStage.setScene(ap);
                }
            });




            //------------------------------------------------------------------------

            // --- Edit catalogue Pane ------------------

            addButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    System.out.println("Add Book has been pressed");
                    primaryStage.setScene(addp);
                }
            });

            removeButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    primaryStage.setScene(rmp);
                }
            });

            main_menu.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    System.out.println("Main Menu has been pressed");
                    primaryStage.setScene(mp);
                }
            });


            // ---- remove book pane

            rm_book_Button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {

                    if (obs.removeBook((Integer.parseInt(ISBN_Field_rm.getText()))) == true){
                        primaryStage.setScene(ap);
                        ISBN_Field.clear();

                    }
                    else{

                        Alert remove_book_fail_alert = new Alert(Alert.AlertType.ERROR);
                        remove_book_fail_alert.setTitle("error !");
                        remove_book_fail_alert.setHeaderText(null);
                        remove_book_fail_alert.setContentText("Book ISBN was not found");
                        remove_book_fail_alert.showAndWait();
                        ISBN_Field.selectAll();
                    }

                }
            });

            cancel_button_rm.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    primaryStage.setScene(ap);
                }
            });

            // --- add book pane

            add_book_Button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    if (obs.publishers.containsKey(Integer.parseInt(publisher_Field.getText()))){
                    obs.addBook(new Book(Integer.parseInt(ISBN_Field.getText()), bookn_Field.getText(),author_Field.getText(),genre_Field.getText(),obs.getPublisher(Integer.parseInt(publisher_Field.getText())),Integer.parseInt(pages_Field.getText()),Integer.parseInt(price_Field.getText()),Integer.parseInt(inventory_Field.getText()),Integer.parseInt(pp_Field.getText())));

                    bookList_main.getItems().clear();
                    bookList_main.getItems().addAll(obs.books.values());

                    bookList.getItems().clear();
                    bookList.getItems().addAll(obs.books.values());

                    primaryStage.setScene(ap);
                    }

                    else{

                        //publisher ID invalid
                    }
                }
            });

            cancel_button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    primaryStage.setScene(ap);
                }
            });

            //----------------------------------------------------------------------

            // --------------- shop Pane

            mm_button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                        primaryStage.setScene(mp);
                    }
            });

            go_shopping_button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    //if (obs.publishers.containsKey(Integer.parseInt(publisher_Field.getText()))){
                        //obs.addBook(new Book(Integer.parseInt(ISBN_Field.getText()), bookn_Field.getText(),author_Field.getText(),genre_Field.getText(),obs.getPublisher(Integer.parseInt(publisher_Field.getText())),Integer.parseInt(pages_Field.getText()),Integer.parseInt(price_Field.getText()),Integer.parseInt(inventory_Field.getText()),Integer.parseInt(pp_Field.getText())));

                        bookList_shopPane.getItems().clear();
                        bookList_shopPane.getItems().addAll(obs.books.values());
                        //bookList.setItems(FXCollections.observableArrayList(obs.books.values().toString()));

                        primaryStage.setScene(sp);
                    }
                //}
            });

            add_to_cart_button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {

                    obs.addToCart(bookList_shopPane.getSelectionModel().getSelectedItem());

                }
            });

            search_for_book_button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {

                    if (obs.books.containsKey(ISBN_Field_shop.getText()))
                    {
                        Book temp = obs.findBook(obs.books.get(ISBN_Field_shop.getText().toString()));

                        bookList_shopPane.setItems(FXCollections.observableArrayList(temp));
                    }

                    else {

                        Alert book_not_found_alert = new Alert(Alert.AlertType.ERROR);
                        book_not_found_alert.setTitle("error !");
                        book_not_found_alert.setHeaderText(null);
                        book_not_found_alert.setContentText("Book Does not Exist\n Please make sure the fields are all correct");
                        book_not_found_alert.showAndWait();
                    }
                }




//                    else{
//
//                        Alert pub_not_found_alert = new Alert(Alert.AlertType.ERROR);
//                        pub_not_found_alert.setTitle("error !");
//                        pub_not_found_alert.setHeaderText(null);
//                        pub_not_found_alert.setContentText("Publisher Does not Exist");
//                        pub_not_found_alert.showAndWait();
//
//                    }

                //}
            });

            search_everything_button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {

                    if (obs.findBook(Integer.parseInt(ISBN_Field_shop.getText()),bookn_Field_shop.getText() ,author_Field_shop.getText(),genre_Field_shop.getText(),obs.getPublisher(Integer.parseInt(publisher_Field_shop.getText()))))
                    {
                        Book temp = obs.getBook(Integer.parseInt(ISBN_Field_shop.getText()),bookn_Field_shop.getText() ,author_Field_shop.getText(),genre_Field_shop.getText(),obs.getPublisher(Integer.parseInt(publisher_Field_shop.getText())));

                        bookList_shopPane.setItems(FXCollections.observableArrayList(temp));
                    }

                    else {

                        Alert book_not_found_alert = new Alert(Alert.AlertType.ERROR);
                        book_not_found_alert.setTitle("error !");
                        book_not_found_alert.setHeaderText(null);
                        book_not_found_alert.setContentText("Book Does not Exist\n Please make sure the fields are all correct");
                        book_not_found_alert.showAndWait();
                    }


                }
            });
            //--------------------- user Pane

            add_user_Button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {

                    if (username_Field.getText().equals("")){

                        Alert username_alert = new Alert(Alert.AlertType.ERROR);
                        username_alert.setTitle("error !");
                        username_alert.setHeaderText(null);
                        username_alert.setContentText("Nothing has been entered into the username field");
                        username_alert.showAndWait();
                        username_Field.selectAll();


                    }
                    else if (obs.usernameExists(username_Field.getText()) == false ) {
                        //obs.addBook(new Book(Integer.parseInt(ISBN_Field.getText()), bookn_Field.getText(),author_Field.getText(),genre_Field.getText(),obs.getPublisher(Integer.parseInt(publisher_Field.getText())),Integer.parseInt(pages_Field.getText()),Integer.parseInt(price_Field.getText()),Integer.parseInt(inventory_Field.getText()),Integer.parseInt(pp_Field.getText())));
                        obs.newUser(new User(username_Field.getText(), ship_Field.getText(), bill_Field.getText(), name_Field.getText()));

                        username_Field.clear();
                        ship_Field.clear();
                        bill_Field.clear();
                        name_Field.clear();

                        primaryStage.setScene(mp);
                    }
                    else {

                        Alert username_alert = new Alert(Alert.AlertType.ERROR);
                        username_alert.setTitle("Username Already Exists !");
                        username_alert.setHeaderText(null);
                        username_alert.setContentText("The Username you have chosen already Exists, Please try a different one");

                        username_alert.showAndWait();
                        username_Field.selectAll();

                    }

                }
            });


            cancel_button_nu.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent e) {
                    primaryStage.setScene(mp);
                }
            });










            primaryStage.show();



        }
        public static void main(String[] args) {
            launch(args);
        }
    }

