public class Book {

    Integer  ISBN, pages, inventory, num_sales;
    Publisher publisher;
    double price;
    float publisher_percentage;


    String  name, author, genre;


    public Book (Integer i, String n, String a, String g, Publisher pub, Integer p, double pr, Integer inv, float perc)
    {
        ISBN = i;
        name = n;
        author = a;
        genre = g;

        publisher = pub;
        pages = p;
        price = pr;
        inventory = inv;

        publisher_percentage = perc;
        num_sales = 0;

    }

    public void sold(){num_sales ++;}

    public String getName(){return name;}

    public Integer getISBN() {
        return ISBN;
    }

    public String getAuthor(){return author;}

    public double getPrice() {
        return price;
    }

    public Publisher getPublisher() {
        return publisher;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "\n" + "Book: " + name + "\nISBN: "+ ISBN + "\nPublisher:"+ publisher.getPublisherName() + "\nNumber of Pages: "+ pages + "\nPrice $"+ price +"\nauthor: "+ author +"\ngenre: "+ genre+ "\n";
    }
}
