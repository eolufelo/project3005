public class Publisher {

    String name, address, email;
    Integer phone_num, bank_acc, id;

    public Publisher (String n, String addy, String em, Integer phone , Integer bank, Integer i){
        name = n;
        address = addy;
        email = em;

        phone_num = phone;
        bank_acc = bank;
        id = i;


    }

    public Integer getId() {
        return id;
    }

    public String getPublisherName(){
        return name.toString();
    }
}
