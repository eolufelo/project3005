import java.util.ArrayList;

public class Order {
    User user;
    ArrayList<Book> books;
    String shipping_ad, billing_ad, tracking;






    public Order(User u, ArrayList<Book> b, String ship, String bill)
    {
        user = u;
        books = b;
        shipping_ad = ship;
        billing_ad = bill;
        tracking = null  ;
    }
}
