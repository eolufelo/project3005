import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.sql.*;
import java.util.Scanner;
import java.util.TreeSet;


public class OnlineBookstoreTestProgram {

    public static void main(String args[]) {


        OnlineBookstore obs = new OnlineBookstore("BookStore1");

        User u1 = new User("User1","123 careltonU road", "123 Carleton road", "Hassem Aouar" );
        User u2 = new User("User2","10 Kanata road", "10 Kanata road", "John Barnes" );
        User u3 = new User("User3","3 Colonel ByDrive road", "3 Colonel ByDrive road", "Emmanuel Petite" );
        User u4 = new User("User4","5 tottenham", "5 tottenham road", "Lucas Moura" );

        obs.newUser(u1);
        obs.newUser(u2);
        obs.newUser(u3);
        obs.newUser(u4);

        Publisher penguin = new Publisher("Penguin Random House", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,001);
        Publisher hachette = new Publisher("Hachette Livre", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,001);
        Publisher harper = new Publisher("HarperCollins", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,001);
        Publisher macmillan = new Publisher("Macmillan Publishers", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,001);
        Publisher simon = new Publisher("Simon & Schuster", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,001);
        Publisher mhe = new Publisher("McGraw-Hill Education", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,001);
        Publisher houghton = new Publisher("Houghton Mifflin Harcourt", "200 colonel by Drive", "big_KB@carleton.ca",18949345,100010020,001);

        Book b1 = new Book(978052552, "The Glass Hotel", "EMILY ST. JOHN MANDEL", "Literary Fiction", penguin, 320,26.95, 10, 5);
        Book b2 = new Book(888052552, "Stop At Nothing: The Explosive New Thriller James Patterson Calls 'flawless'", " Michael Ledwidge", "Mystery", hachette, 303,14.99, 10, 5);

        obs.addBook(b1);
        obs.addBook(b2);

        //obs.printBooks();



        //obs.purchase(books_in_cart, u1, "123 carelton road", "123 Carleton road");


    }
}





/*
import java.sql.*;
        import java.util.Scanner;
        import java.util.TreeSet;

public class FindPrereqs {
    public static void main(String[] args) {
        String id;
        System.out.print("enter the id of the course you would like to find the prerequisites for: ");
        Scanner scan = new Scanner(System.in);
        id = scan.next();
        TreeSet<String> queried_ids =new TreeSet<String>();
        ResultSet resultSet;

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:5432/postgres", "postgres", "student");
             Statement statement = connection.createStatement();
        )

        {
            statement.executeUpdate("create table list_of_prereqs"
                    + "(prereq_id varchar(8)"
                    + "primary_key (prereq_id));");

            resultSet = statement.executeQuery("select prereq_id from prereq where course_id=" + id);


            while (true) {
                if (queried_ids.contains(resultSet.getString("prereq_id"))) {
                    //if this statement is reached, then that means the loop is about to repeat so we must break
                    break;
                }

                else {

                    // update our relation
                    statement.executeUpdate("insert into prereq_id "+ resultSet.getString("prereq_id"));

                    //add out result to out treeset to note that the id has been queried.
                    queried_ids.add(resultSet.getString("prereq_id"));

                    //proceed to next id (which is the prereq_id or our current_id)
                    resultSet = statement.executeQuery("select prereq_id from prereq where course_id=" + resultSet.getString("prereq_id"));
                }
            }


            resultSet = statement.executeQuery("select prereq_id"
                    + "from list_of_prereqs");

            while (resultSet.next()) {
                System.out.printf(resultSet.getString("prereq_id"));
            }

            statement.executeUpdate("drop table list_of_prereqs");

        } catch (Exception sqle) {
            System.out.println("Exception: " + sqle);
        }
    }
}*/