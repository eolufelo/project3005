import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

public class OnlineBookstore {
    HashMap<Integer, Book> books = new HashMap<Integer, Book>();
    HashMap<Integer,Publisher> publishers = new HashMap<Integer,Publisher>();
    HashMap<String,User> users = new HashMap<String,User>();
    ArrayList<Book> cart = new ArrayList<>();
    String bookStoreName;

    public OnlineBookstore(String n){
        bookStoreName = n;
    }

    public boolean searchByIsbn(Integer ISBN){
        return books.containsKey(ISBN); }

    public boolean available(Integer ISBN){
        return (books.get(ISBN).inventory > 0);
    }
    public boolean usernameExists(String u){

        if (users.containsKey(u)) { return true;}
        return false;

    }

    public boolean newUser (User u){

        if (users.containsKey(u.getUsername())) { return false;}

            users.put(u.getUsername(), u);
            return true;

    }

    public Publisher getPublisher(int id) {
        if (publishers.containsKey(id)) return publishers.get(id);
        else return null;

    }

    public boolean publisherExists(int id){
        if (publishers.containsKey(id)) return true;
        else return false;
    }

    public void addPublisher(Publisher p){publishers.put(p.getId(), p);}

    public void addBook(Book b){

        if (books.containsKey(b.getISBN())) return;
        else {books.put(b.getISBN(), b);}

    }


    public void purchase(ArrayList<Book> b, User u, String ship, String bill){


        Order o = new Order(u,b, ship, bill);
        for (int i = 0; i < b.size(); i++)
        {
            b.get(i).sold();
        }
    }

    public boolean findBook(Integer i, String n, String a, String g, Publisher pub){
        Book temp;
        if (books.containsKey(i)){
            temp = books.get(i);
            if (temp.getISBN() == i && temp.getName() == n && temp.getAuthor() == a && temp.getGenre()==g && temp.getPublisher() == pub)
            return true;
        }

        return false;
    }

    public Book getBook(Integer i, String n, String a, String g, Publisher pub){
        Book temp;
        if (books.containsKey(i)){
            temp = books.get(i);
            if (temp.getISBN() == i && temp.getName() == n && temp.getAuthor() == a && temp.getGenre()==g && temp.getPublisher() == pub)
                return temp;
        }

        return null;

    }
    public Book findBook(Book b){

       if( books.containsKey(b.getISBN())) return books.get(b.getISBN());
       else {return null;}
    }


    public boolean removeBook(Integer i){

        if (books.containsKey(i)) {books.remove(i); return true;}
        else {return false;}
    }

    public void addToCart(Book b){cart.add(b);}

    public void clearCart(){cart.clear();}

    public void checkout(User u,String ship, String bill ){

        if (users.containsKey(u)){

            User temp = users.get(u);

        }

        clearCart();
    }


    public void printBooks(){System.out.print(books.values());}

    @Override
    public String toString() {
        return super.toString();
    }
}
